#!/bin/bash
vogais=("a" "e" "i" "o" "u")
read -p "Informe uma palavra: " pal
for i in `seq 1 ${#pal}` ;do
	for v in `seq 0 4` ;do
		if [ "${vogais[$v]}" == `echo $pal | cut -c$i-$i` ]; then
			cont=$[ $cont + 1 ]
		fi
	done
			
done

echo "A palavra contém $cont vogais"

