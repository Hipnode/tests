#!/bin/bash

coproc bc

for N in {1..10};do
	for M in {1..10};do
		echo "$N * $M" >&${COPROC[1]}
		read -u ${COPROC[0]} saida
		echo "$N x $M = $saida"
	done		
done


