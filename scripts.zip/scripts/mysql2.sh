#!/bin/bash
DB_USERNAME="root"
DB_PASSWORD="dois-1=1"
DB_DATABASE="estudos"

declare -A dados;

function DBInsert(){
	dados=$1
	chaves=$( for keys in ${!dados[@]};do
		 	chaves+="$keys "
		  done
		echo "$chaves" | tr " " ","
	)
}

dados=(
	["nome"]="Wellinton"
	["email"]="wellinton@hotmail.com"
	["idade"]=18
	["status"]=1
)


        for values in ${!dados[@]};do
             valores+="'${dados[$values]}' "
	done

	


echo $valores | tr " " ","
