validPhoneNumber(){
        if [ `echo $1 | egrep -w '\('[0-9]{3}'\)'' '[0-9]{3}-[0-9]{4}` ]; then
                echo "True"
        else
                echo "False"
        fi

}
validPhoneNumber $1

