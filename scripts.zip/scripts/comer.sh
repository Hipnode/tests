#!/bin/bash
clear
if [ ! -d ~/.clientes ];then
	mkdir ~/.clientes
fi	

function pausa(){
	read -p "Pressione ENTER para continuar ou digite 1 para voltar ao menu principal " res
		if [ $res == 1 ];then
			clear
			main
		fi
}

function addclient(){
	read -p "Informe o nome do cliente: " cliente
	nome=`echo $cliente | tr A-Z a-z`
	if [ ! -f ~/.clientes/$nome.txt ]; then 
		touch ~/.clientes/$nome.txt 
			if [ $? == 0 ]; then
				echo "Cliente Adicionado !!"
				pausa
				addclient
			fi
	else
		echo -e "O nome já consta no banco de dados \nInforme outro nome, por favor."
		pausa
		clear
		addclient
	
	fi
	
	main
}

function addprod(){
	#read -p "Informe o nome do cliente: " cliente
	select cliente in `ls ~/.clientes/ | cut -d'.' -f1`;do
	read -p "Informe o nome do produto: " produto
	read -p "Informe o preço do produto: " preco
	
		if [ -f ~/.clientes/$cliente.txt ];then
			echo -e "$produto\t\t$preco" >> ~/.clientes/$cliente.txt
				if [ $? == 0 ];then
					echo "Produto Adicionado!!"
					pausa
					addprod
				fi
		else
			echo "O cliente não está cadastrado"
			pausa
			addprod	
		fi
	done

}

function conclient(){
	
	#read -p "Informe o nome do cliente: " cliente
	echo "========= = ======="
	echo "Selecione o cliente" 
	select cliente in `ls ~/.clientes/ | cut -d'.' -f1`; do
	if [ -f ~/.clientes/$cliente.txt ];then
		clear
		cat ~/.clientes/$cliente.txt | tr , . | 
		awk 'BEGIN{ printf("=======\t\t=====\nPRODUTO\t\tPREÇO\n\n")}{ print $0 ; sum+=$2 }END{ printf("\nTOTAL:		%.2f\n",sum)}'
		pausa
		conclient
	else
		echo "O cliente não consta no banco de dados"
	fi

	done

}

function delete(){
	read -p "Informe o nome do cliente: " cliente
	if [ -f ~/.clientes/$cliente.txt ]; then
		rm -r ~/.clientes/$cliente.txt
		if [ $? == 0 ];then
			echo "Cliente excluido!!"
			pausa
			delete
		fi
	else
		echo "O cliente não consta no banco de dados"
		pausa
	fi

}

function reset(){
	select cliente in `ls ~/.clientes/ | cut -d'.' -f1`;do
		if [ -f ~/.clientes/$cliente.txt ]; then
			echo "" > ~/.clientes/$cliente.txt
			if [ $? == 0 ]; then
				echo "Conta quitada!!"
				pausa
				reset
			fi
		else
			echo "O cliente não consta no banco de dados"
			pausa
		fi

	done

}

function main(){
echo " 			 === ==================  "
echo "	 		  1  Incluir cliente     "
echo "			  2  Incluir produto     "
echo "			  3  Consultar cliente   "
echo "			  4  Excluir cliente     "
echo "			  5  Zerar conta	        "
echo " 			  6  Sair	        "
read -p "Opção: " op
	case $op in 
		1) addclient;;
		2) addprod;;
		3) conclient;;
		4) delete;;
		5) reset;;
		6) clear;exit;;
		*) echo -e "Opção Inválida!! \n";
		read -p "Pressione ENTER para continuar" enter
		clear
		main;
	esac 
}

main
