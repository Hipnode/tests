#!/bin/bash

clear
if [ $UID == 0 ]; then
	while true 
	do
		while read linha
		do 
			echo "$linha" | tr '(unknow)' ''
			if [ ${linha} ~= "7C:8B:B5:87:7B:55" ]
			then
				echo "Rafael está conectado"
			fi
			
		done < <( nmap -sP $(route -n | awk '$4 == "UG" {print $2}')/24 | grep -i mac | cut -c 13- )

	sleep 10 
	clear
	done
else 
	echo "Execute como root"

fi
