#!/bin/bash

sort(){
	STR=$1
	echo $STR | grep -o '.' | sort -n | tr -d '\n'
}

[[ `sort $1` == `sort $2` ]] && echo "É anagrama!!" || echo "Não é anagrama"
