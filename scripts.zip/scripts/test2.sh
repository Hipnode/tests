#!/bin/bash
number=0
until [ $number -gt 20 ] && [ $number -lt 30 ];do
	read -p "Informe um número: " number;
	
done

