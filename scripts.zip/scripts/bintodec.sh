#!/bin/bash
C=0;
read -p "Informe o número binário: " bin
NUM=$(( ${#bin} - 1))

for ((i=$NUM; i >= 0;i--));do
	DEC=$(( $DEC + $( bc <<< "${bin:$i:1} * 2^$C" ) ))
	((C++))
	
	(( $i % 3 == 0 )) && echo $i
done
echo $NDEC
