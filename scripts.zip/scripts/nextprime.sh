#!/bin/bash

function isPrime(){
	
	primo=0
	for i in `seq 2 $(($1-1))`
	do
		(( $1 % $i == 0 )) && primo=1;
	done

	echo $primo

}



