#!/bin/bash

	
	read -p "Informe um número: " num;
		for (( b = 1; b <= num; b++))
		do
			if (( $num % $b == 0 )); then
				cont=$[ cont + 1 ];
			fi
		done

	if [ $cont -le 2 ]; then
		echo "É primo"
	else 
		echo "Não é primo"
	fi

	
	
