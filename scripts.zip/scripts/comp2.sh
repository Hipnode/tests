#!/bin/bash
find ~ -iname '*.c' -cmin -1 -exec gcc '{}' \;
./a.out

