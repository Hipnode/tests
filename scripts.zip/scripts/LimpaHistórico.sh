#!/bin/bash

if [ ` pidof firefox > /dev/null ; echo $? ` == 1 ]; then
	rm .mozilla/firefox/fzgfhe7h.default/formhistory.sqlite
		if [ $? == 0 ]; then
			echo "Histórico limpo"
		
		else 

			echo "O histórico não pôde ser limpo"
		fi
else 	
	echo "O Firefox precisa ser fechado"


fi 

