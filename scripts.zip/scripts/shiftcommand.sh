#!/bin/bash
sum=0
count=1
for i in $(seq 1 $#);do
	(( $i > 9 )) && shift 9 && count=1; 
	#(( $i < 9 )) && param='$'$i || (( $i > 9 )) && param='${'$i'}'
	param='$'$count
	sum=$[ $sum + $( eval echo $param ) ]
	(( count++ ))
done

echo "Soma dos parâmetros: $sum"
