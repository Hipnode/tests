#!/bin/bash

while read linha;do
	echo $linha
done < file
