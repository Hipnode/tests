#!/bin/bash
find ~ -iname '$1' -exec grep -i "$2" {} \;
