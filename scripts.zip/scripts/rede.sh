#!/bin/bash
main(){
echo -e " 1 - Incluir \n 2 - Deletar \n 3 - Ver \n 4 - Limpar \n 5 - Sair" 
read -p " > " op;

	case $op in 
		1) incluir  ;;
		2) excluir ;;
		3) ver ;;
		4) limpar ;;
		5) exit ;;

  	esac

}

incluir(){

	read -p "Informe o nome da rede: " nome;
	read -p "Informe a senha: " senha;
	echo -e "$nome \t $senha" >> wifipass.txt
	clear	
	main;
}

excluir(){
	read -p "Informe o nome da rede: " nome;
	sed -i '/$nome/d' wifipass.txt
	clear
	main;
}

ver(){
	cat wifipass.txt
	echo " "
	read -p "Pressione enter para voltar..." fa;
	clear
	main;
}

limpar(){

	echo " " > wifipass.txt
}
main;
