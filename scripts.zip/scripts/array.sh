#!/bin/bash

#Declaração do array associativo
declare -A pessoas

#Preenchendo o array 

pessoas=(
	["Wellinton"]=18
	["Jeziel"]=11
	["Lorena"]=1
)


#Percorrendo o array 

for pessoa in ${!pessoas[@]}; do
	pessoas+="$pessoa "	
	echo "$pessoa tem ${pessoas[$pessoa]} anos"
done


echo $pessoas | tr ' ' ", "
