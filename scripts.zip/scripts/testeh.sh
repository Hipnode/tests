#!/bash/bin
maior=0
for i in `ls *.sh`; do
	if [ `cat $i | wc -l` -gt  $maior ]; then
		maior=`cat $i | wc -l`
		arq=$i
	fi			
	
done
echo "O maior arquivo é $arq"
echo "O maior arquivo contém $maior linhas"
echo -n "Deseja visualiza-lo? [s/n] "
read resp
	if [ "$resp" = 's' ] || [ "$resp" = 'S' ]; then
		cat $arq | more
	fi
