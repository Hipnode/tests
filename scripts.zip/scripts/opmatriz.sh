#!/bin/bash
declare -a mtz
for (( i = 0; i < 3; i++ ));do
	for (( j = 0; j < 3; j++ ));do
		read -p "[$i,$j]: " pos
		mtz[$i,$j]=$pos
			if [ $i == $j ];then
				sum=$[ $sum + ${mtz[$i,$j]} ]
			fi
	done
done 

echo $sum
