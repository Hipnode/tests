#!/bin/bash
read chr
if [ $chr = "Y" ] || [ $chr = "y" ]; then
	echo "YES"
elif [ $chr = "N" ] || [ $chr = "n" ]; then
	echo "NO"
fi
