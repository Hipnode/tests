#!/bin/bash

declare -A extensoes

extensoes=(
	["sh"]="Arquivo Shell Script"
	["c"]="Arquivo C"
	["html"]="Página HTML"
	["txt"]="Documento de texto"
)

for arq in `ls | cut -d'.' -f 2` ;do
	for ext in ${!extensoes[@]} ;do
		if [ $arq == $ext ]; then
			echo "${extensoes[$ext]}"
		fi
	done
done

