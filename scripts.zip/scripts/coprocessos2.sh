#!/bin/bash

coproc bc 

exec 5<&1

exec 0<&${COPROC[0]}
exec 1>&${COPROC[1]}

for A in {1..9};do
	echo "$A * $A"
	read R
	echo "$A * $A = $R" >&5
done

exec 5<&-


