#!/bin/bash
soma=0;
read -p "N1: " n1;
read -p "N2: " n2;

for i in `seq $n1 $n2`;do
	if (( $i % 2 != 0 )); then
		soma=$(( $soma + $i ));
	fi
done

echo $soma
