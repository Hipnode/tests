#!/bin/bash
for i in '*.sh'; do
	if [ `grep -i -c 'for' $i` \> 2 ]; then
		echo $i
	fi
done
