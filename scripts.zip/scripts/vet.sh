#!/bin/bash

        read -a vetor <<< $*
        tam=${#vetor[@]}
                for (( i = $tam ; i >= 0; i-- ));do
                        echo -n "${vetor[$i]} "
                 done



