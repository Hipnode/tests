#!/bin/bash
while [ $numero \!= $rand ]; do
	rand=$(($RANDOM % 9))
	read -p "Informe um número: " numero;
		if [ $rand == $numero ]; then
			echo "Vc acertou!!"
		elif [ $rand \< $numero ]; then
			echo "O número sorteado é menor"
		else
			echo "O número sorteado é maior"
		fi

done
