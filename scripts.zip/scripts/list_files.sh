#!/bin/bash
find $1 -type f | sed -e 's/.*\.//' | sort | uniq -c


