#!/bin/bash
declare -a VET
function ler(){
        for(( i = 0; i < $1; i++ ));do
                printf "%iº posição: " $(($i+1))
                read num
                VET[$i]=$num
        done

}



function bubble_sort(){
	SIZE=$1
	for (( i = 1; i < $SIZE; i++));do
		for (( j = 0; j < $SIZE-$i-1; j++));do
			if [[ ${VET[$j]} > ${VET[$j+1]} ]];then
				AUX=${VET[$j]}
				VET[$j]=${VET[$j+1]}
				VET[$j+1]=$AUX
				
			fi
		done
	done

}

read -p "Tamanho do vetor: " tam

ler $tam

bubble_sort 5

echo ${VET[@]}
