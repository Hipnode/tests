#!/bin/bash

function tr(){
	declare -A hex
	hex=( ["A"]=10 ["B"]=11 ["C"]=12 ["D"]=13 ["E"]=14 ["F"]=15 )
	return ${hex[$1]}
}

read -p "Hexadecimal: " hexa

for i in $( seq 0 $((${#hexa}-1)))
do
	h=tr ${hexa:$i:1}
	echo $h 
done

