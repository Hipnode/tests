#!/bin/bash
cd $1
for ext in $( ls *.* | cut -d'.' -f2 | sort -u );do
	printf "%10s: %d \n" "$ext"  "$( ls *.* | grep -c .$ext$ )" | tr a-z A-Z  
done

 

