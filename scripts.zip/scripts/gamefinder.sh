#!/bin/bash

read -p "Informe o nome do jogo: " jogo
l=$(echo $jogo | cut -c1-1)

for i in `curl www.freeroms.com/psx_roms_$l.htm`
	do
		echo $i | grep -i $jogo
done
