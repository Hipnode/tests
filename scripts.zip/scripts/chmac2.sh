#!/bin/bash
function exibeinterfaces(){
	echo " Selecionea um interface de rede"
	echo " ===  ====================================================="
	echo "  1 - $(ifconfig | grep -i link -m1  | awk '{ print $1 }') "
	echo "  2 - $()"
	read int
}

function validamac(){
	VALID="^[0-9A-Za-z]{2}(:|-)[0-9A-Za-z]{2}(:|-)[0-9A-Za-z]{2}(:|-)[0-9A-Za-z]{2}(:|-)[0-9A-Za-z]{2}(:|-)[0-9A-Za-z]{2}$"
	if [[ $1 =~ $VALID ]]; then
		echo "MAC válido"
		
		return 0
	else 
		echo "MAC inválido"
		return 1
	fi
}

function trocamac(){
	ifconfig 

}

read -p "Informe o novo MAC: " mac
validamac $mac
	if [ $? == 1 ]; then
		echo "Não foi possível trocar o MAC"
	else
		exibeinterfaces
	fi
