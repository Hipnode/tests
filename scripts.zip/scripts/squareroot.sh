#!/bin/bash

function sqrt(){
        for (( i = 1; i < $1 ; i++ )) do
              #  if (( $1 % $i == 0 )); then
                        if (( $i * $i == $1 )); then
                                echo "Raíz quadrada: $i"
				break
                        fi
               # fi
        done
}

echo -n "Informe um número: "
read num
sqrt $num


