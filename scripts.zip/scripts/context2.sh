#!/bin/bash
ls -1 $1 | cut -d'.' -f2 -s | sort | uniq -c

