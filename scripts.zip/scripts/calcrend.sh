#!/bin/bash
materias=("Limite" "Derivada" "Integral" "seila")
total=0;
for (( i = 0; i < 4; i++ )); do
	read -p "Porcentagem de redimento em ${materias[i]}: " rend;
	total=$[ total + ($rend*25 / 100) ];
done

echo "Estimativa de nota: $total%"
	
