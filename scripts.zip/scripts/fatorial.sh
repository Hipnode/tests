#!/bin/bash

fatorial(){

	if [ $1 == 0 ]; then
		return 0;
	else
		return $(( $1 * fatorial $(($1 - 1)) ));
	fi
}


read -p "Informe um número: " num;
fatorial $num
