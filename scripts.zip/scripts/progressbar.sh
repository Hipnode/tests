#!/bin/bash

t=0;
while [ $t -lt 100 ];
do t=$[t+1];
echo $t;sleep 0.05;
done\
| dialog --gauge "Carregando o Sistema..." 6 75 		
