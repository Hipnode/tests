#!/bin/bash

balance(){
	while read "$1"
	do
		echo $1
	done

}

balance "$1"
