  #!/bin/bash
  
  echo "content-type: text/html"
  echo
  echo
  echo "
  <html> <head> <title> CGI script </title> </head>
  <body>
  "
  
  echo "<h2>Exemplo de uso do GET</h2>"
  if [ "$QUERY_STRING" ];then
  	echo "QUERY_STRING   $QUERY_STRING"
  	host="$(echo $QUERY_STRING | sed 's/\(.*=\)\(.*\)\(\&.*\)/\2/')"
  	echo "<br>"
  	echo "Disparando o comando ping para o host <b>$host</b>"
  	echo "<pre>"
  	ping -c5 $host
  	echo "</pre>"
  	echo "Fim."
  else
  	echo "
  	<form method=\"GET\" action=\"ping_get.cgi\">
  	<b>Entre com o nome ou IP do host para o ping:</b> 
  	<input size=40 name=host value=\"\">
  	<input type=hidden size=40 name=teste value=\"nada\">
  	</form>"
  fi
  
  echo "</body>"
  echo "</html>"
