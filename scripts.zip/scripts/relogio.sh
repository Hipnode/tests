#!/bin/bash

while :
do
	echo $( date | awk '{ print $4}' )
	sleep 1
	clear
done
