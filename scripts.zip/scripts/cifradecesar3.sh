#!/bin/bash
CHAVE=$1
MENSAGEM=$2
CONT=0
ALFABETO1=({a..z})
ALFABETO2=$( 
	while [ $CONT -le 25 ];do
		echo -n ${ALFABETO1[($CONT+$CHAVE)%26]}
		(( CONT++ ))
	done
)

ALFABETO1=$( echo ${ALFABETO1[@]} | tr -d ' ' )
	
echo $MENSAGEM | tr $ALFABETO1 $ALFABETO2
