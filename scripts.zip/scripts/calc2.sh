#!/bin/bash

coproc bc

for i in {1..10};do
	echo "$i*$i">&${COPROC[1]}
	read -u ${COPROC[0]} r
	echo $r
done

