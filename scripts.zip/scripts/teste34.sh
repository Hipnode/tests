#/bin/bash

vet=(aa aa ab bb cb)

vet2=( echo ${vet[@]} | \
	tr ' ' '\n'   | \
	sort -u       | \
	tr '\n' ' ' )

echo ${vet[@]}
