#!/bin/bash

echo $1
echo $2
shift 9
echo $1
