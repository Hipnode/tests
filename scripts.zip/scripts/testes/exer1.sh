#!/bin/bash
#vetor=(Namibia Nauru Nepal Netherlands NewZeland Nicaragua Niger Nigeria NorthKorea Norway)
read -a vetor <<< "$@"
for i in ${!vetor[@]}
do
    if [ $(echo ${vetor[$i]} | grep -i 'a') ];then
        unset vetor[$i]
    fi
done

echo ${vetor[@]}

