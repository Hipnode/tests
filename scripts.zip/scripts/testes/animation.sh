#!/bin/bash

vetor=( '/' '-' '\' '|' )

while : 
do
	for i in ${vetor[@]};do
		echo "Copying files $i"
		sleep .2
		clear
	done
done
	
