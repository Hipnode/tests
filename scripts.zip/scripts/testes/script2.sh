#!/bin/bash

while read nome n1 n2 n3 n4;do
		echo "$nome teve média $(( ($n1 + $n2 + $n3 + $n4) / 4  ))"
done < $1
