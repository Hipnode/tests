#!/bin/bash
i=0;

while read x
do
    vetor[$i]=$x
    ((i++))
done

for i in ${!vetor[@]};do
    size=${#vetor[$i]}
    vetor[$i]=".${vetor[$i]:1:$((size-1))}"
    
done

echo ${vetor[@]}
