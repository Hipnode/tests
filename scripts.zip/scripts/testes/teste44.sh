#!/bin/bash

#coproc bc 

#echo "4*80" >&${COPROC[1]}
#read -u ${COPROC[0]} RESULT
#echo $RESULT

#echo "4*80" | bc

coproc tr '[a-z]' '[A-Z]' 

nomes=('Wellinton' 'lajsflçak' 'klajsdfka' 'kjaksdjf')


#for nome in ${nomes[@]};do
#	echo $nome >&${COPROC[1]}
#	read -u ${COPROC[0]} UPPER
#	echo $UPPER
#done

echo ${nomes[0]} >&${COPROC[1]}
read -u ${COPROC[0]} saida
echo $saida
