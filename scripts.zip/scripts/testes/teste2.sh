#!/bin/bash
IFS=:
while read a b c d e f g;do
	
	echo -e "$a\t\t$g"
done < /etc/passwd
