#!/bin/bash

for i in `ls *.txt`;do
	[[ $( cat $i | wc -l ) > $maior ]] && \
	maior=$( cat $i | wc -l ) && arq=$i
done

rm -i $arq
