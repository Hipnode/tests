#!/bin/bash

coproc bc


while read linha ;do 
	echo $(echo $linha | tr ' ' '+' | bc)/3 | bc
done < arquivo
