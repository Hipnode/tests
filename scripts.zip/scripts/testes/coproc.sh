#!/bin/bash

coproc bc

exec 6<&1

exec 0<&${COPROC[0]}
exec 1<&${COPROC[1]}

for i in {1..9};do
	echo "$i * $i"
	read resposta
	echo "$i * $i = $resposta" >&6
done

exec 6<&-


