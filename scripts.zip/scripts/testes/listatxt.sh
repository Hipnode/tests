#!/bin/bash

for file in *.txt
do
	[ $( cat $file | wc -l ) -gt $1 ] && echo $file
	
done
