#!/bin/bash

var=" " 
for n in {a..g}
do
	var="$var $n"
done

echo $var 
