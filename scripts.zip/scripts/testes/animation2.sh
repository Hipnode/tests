#!/bin/bash

vetor=('.' '..' '...')

while true;do
	for i in ${vetor[@]};do
		echo "Loading$i"
		sleep .2
		clear
	done
done
