#!/bin/bash


read -a vetor <<< "$@"
echo ${vetor[@]}
