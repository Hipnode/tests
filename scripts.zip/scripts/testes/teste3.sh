#!/bin/bash
soma=0;
IFS=":"
echo -e "Nome\t\tNota"
while read nome notas;do
	echo -e "$nome\t\t$notas"
	soma=$[ soma + notas ];
done < notas.txt

echo "Total: $soma"
