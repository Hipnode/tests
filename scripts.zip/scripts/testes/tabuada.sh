#!/bin/bash

for i in {1..9};do
	echo "$i * $i = $(( $i*$i ))"
done
