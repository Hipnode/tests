#!/bin/bash
COL1WIDTH="8.3333"
for i in {1..12};do
	[[ $i == 12 ]] && echo ".col-$i{ width: 100% }" && break
	echo .col-$i{ width: $( bc <<< "$i * $COL1WIDTH" )% }
done > $1
