#!/bin/bash

IFS=":"
declare -a nomes
declare -a notas
C=0
while read nome nota
do
	nomes[$C]=$nome
	notas[$C]=$nota
	(( C++ ))
done < notas.txt

echo ${nomes[@]}
echo ${notas[@]}

