#!/bin/bash
i=0
while read x;do
    vetor[$i]=$x
    ((i++))
done

for i in ${!vetor[@]}
do
    if [ $(echo ${vetor[$i]} | grep -i 'a') ];then
        unset vetor[$i]
    fi
done

echo ${vetor[@]}
