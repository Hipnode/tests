#!/bin/bash

echo $-
