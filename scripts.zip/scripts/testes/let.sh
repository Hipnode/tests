#!/bin/bash

i=9999;

for (( i = 0; i < 10; i++));do
	echo $i
done

echo "After loop: $i"
