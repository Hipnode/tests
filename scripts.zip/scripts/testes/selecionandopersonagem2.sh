#!/bin/bash

exec 3<&1
>/tmp/file
exec 3</tmp/file
	vetor=("Arara" "Elefante" "Passarinho" "Hipopótamo" "Pinguim")
	for i in {1..99};do
		echo ${vetor[$RANDOM%5]}
	done 
exec 3<&-

cat /tmp/file | sort | uniq -c 

