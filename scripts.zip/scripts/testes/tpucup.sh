#!/bin/bash
tput cup 10 10
figlet login
tput cup 10 20
read -p "Usuário: " user
clear

while [[ $password != '123' ]];do
	clear	
	tput cup 10 20
	read -s -p "Senha: " password
	if [[ $password == '123' ]];then
		echo "Vc logou no sistema"
	else
		tput cup 20 30
		echo "Senha inválida"
	fi
done


