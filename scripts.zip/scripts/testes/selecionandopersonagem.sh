#!/bin/bash

vetor=("Arara" "Elefante" "Passarinho" "Hipopótamo" "Pinguim")
for i in {1..99};do
	echo ${vetor[$RANDOM%5]}
done > users 

cat users | sort | uniq -c 

