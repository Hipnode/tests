#!/bin/bash

read -p "Deseja continuar? " responda
echo ${responda:?"(S)Sim ou (N)Não"}
