#!/bin/bash

echo $* | bc
