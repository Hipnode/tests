#!/bin/bash

cat $1 |
	( while read nome nota
	do
		if [[ $nota -ge 7 ]];then
			echo "$nome foi aprovado"
		else
			echo "$nome foi reprovado"
		fi
	done
	) 
