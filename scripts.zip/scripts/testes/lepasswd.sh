#!/bin/bash
IFS=':'
cat /etc/passwd | while read a b c d e f g;do
	echo $a: $g
done
