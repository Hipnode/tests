#!/bin/bash
declare -a vetpos
t=0
c=0
vetor=("super" "bowl" "bow")
read -p "Palvra: " pal
for word in ${vetor[@]};do
	if [[ $( echo $pal | grep -io $word ) == $word ]];then
		vetpos[$c]=$t
		((c++))
	fi
	((t++))
done

echo ${vetpos[@]}
