#!/bin/bash

LINES=0

for file in $(ls *.txt);do
	NLines=$(cat $file | wc -l) 
	if [[ $NLines -gt $LINES ]];then
		LINES=$NLines
		ARQ=$file
	fi	
	
done

echo $ARQ


