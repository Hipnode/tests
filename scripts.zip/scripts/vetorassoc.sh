#!/bin/bash

declare -a vet;


