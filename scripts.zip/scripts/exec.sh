#!/bin/bash

exec 6<&1

exec 1>/tmp/filesaida

A=0

while [ $A -lt 10 ];do
	echo $A
	let A++
done

exec 1<&6

cat /tmp/filesaida
