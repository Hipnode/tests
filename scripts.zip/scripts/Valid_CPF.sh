#!/bin/bash

[[ $1 =~ ^([0-9]{3}(\.|\-)){3}[0-9]{2}$ ]] && echo "CPF Válido" || echo "CPF Inválido"
