#!/bin/bash

var=$(zenity --list \
 --title="Escolha" \
 --column="Opção" --column="Evento" \
 --width=500\
 --height=600\
  1 Cadastrar \
  2 Incluir \
  3 Alterar \
  4 Buscar \
  5 Excluir \
)

echo $var
