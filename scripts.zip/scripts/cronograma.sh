#!/bin/bash
clear
declare -A tasks
tasks[0,0]="        "
tasks[0,1]="  Seg.  "
tasks[0,2]="  Ter.  "
tasks[0,3]="  Qua.  "
tasks[0,4]="  Qui.  "
tasks[0,5]="  Sex.  "

tasks[1,0]="18:00"
tasks[2,0]="18:45"
tasks[3,0]="19:30"
tasks[4,0]="20:15"
tasks[5,0]="21:00"
tasks[6,0]="21:15"

read -p "Escreva a sua tarefa: " task
echo "1 - Urgente"
echo "2 - Importância razoável"
echo "3 - De pouca importância"
echo -n "Opção:"
read op

case $op in 
	1) tasks[1,2]="\e[41;1m $task \e[m";;
	2) tasks[1,2]="\e[43;1m $task \e[m";;
	3) tasks[1,2]="\e[42;1m $task \e[m";;
	esac
clear

echo "Legenda: "
echo -e "\e[41;1m   \e[m Urgente" 
echo -e "\e[43;1m   \e[m Importância razoável"
echo -e "\e[42;1m   \e[m De pouca importância"
echo ""


for (( i = 0; i < 7; i++));do
	for (( j = 0; j < 6; j++));do
		printf "${tasks[$i,$j]} \t\t"	
	done
	printf "\n"
done
