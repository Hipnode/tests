#!/bin/bash

read -p "Divisor: " divisor
read -p "Dividendo: " dividendo

while [ $divisor \> 0 ];do
	(( $divisor \< 0 )) && break
	(( divisor -= dividendo ))
	(( count++ ))
	echo $divisor
done

echo $count
	
