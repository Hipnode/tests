#!/bin/bash

#for A in {1..50};do
#	echo "$A*$A" | bc 
#done

coproc bc

for A in {1..50};do
	echo "$A*$A">&${COPROC[1]}
	read -u ${COPROC[0]} r
	echo $r
done

