#!/bin/bash

declare -A matrix

for (( row = 5; row > 0; row-- ));do
	for (( col = 5; col > 0; col-- ));do
		matrix[$row,$col]="*"
	done
done

for (( row = 5; row > 0; row-- ));do
	for (( col = 5; col > 0; col-- ));do
		printf "${matrix[$row,$col]}"
	done
	printf "\n"
done
