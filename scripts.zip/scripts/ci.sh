#!/bin/bash

KEY="chave.key"
STRING=$1

# Função de criptografia por substituição

cripto(){
QTDD=${#STRING}

for CHAR in `seq 1 $QTDD`;do
	
	BIT=$( echo $STRING | cut -c$CHAR )
	BIT_NEW=$( grep "$BIT=" $KEY | awk -F'=' '{ print $2 }' )
	printf "$BIT_NEW"
done

echo 

}

cripto
