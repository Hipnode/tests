#!/bin/bash
cont = 1;
for i in `seq 100 1000`; do
	for t in `seq 0 $i`; do
		if [ `expr $i % $t` -eq 0 ]; then
			$cont = $(( cont + 1 ));
		fi
	done
	
	if [ $cont -eq 2 ]; then
		echo "$i é primo"
	fi
		
done  
