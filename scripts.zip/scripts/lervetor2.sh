#!/bin/bash
declare -a vetor
read -p "Informe quantos nomes você quer adicionar? " n
for (( i = 0; i < n; i++ ))
	do	
		read -p "Informe o $(( $i + 1))º nome: " nome
		vetor[$i]=$nome
done

echo ${#vetor[@]}
