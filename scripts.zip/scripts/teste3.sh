#!/bin/bash

#IFS="\n"

while read linha;do
	echo $linha
done < file
