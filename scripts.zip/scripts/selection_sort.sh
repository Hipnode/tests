#!/bin/bash
declare -a vet
function ler(){
	for(( i = 0; i < $1; i++ ));do
		printf "%iº posição: " $(($i+1))
		read num
		vet[$i]=$num
	done

}

function selection_sort(){
	for(( i = 0; i < $1; i++));do
		for(( j = i+1; j < $1; j++));do
			if [[ ${vet[$j]} < ${vet[$i]} ]];then
				aux=${vet[$i]}
				vet[$i]=${vet[$j]}
				vet[$j]=$aux
			fi
		done
	done
}

read -p "Informe a quantidade de número a serem ordenados: " qtd
ler $qtd
selection_sort 5
echo ${vet[@]}
