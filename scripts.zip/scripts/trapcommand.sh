#!/bin/bash
erro(){
	echo "Não interrompa o processo"
	echo "Seu fiho da puta"
}

trap "echo Use quit para sair" SIGINT 

for i in {1..10}
do	
	l=$(( $l + 10 ));
	echo "Loading $l%"
	sleep 3
	clear
		if [ $

done

