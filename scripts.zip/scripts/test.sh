#!/bin/bash
for i in ~/* 
do
	echo $i | cut -d'/' -f4 | cut -d'.' -f1 
done 
