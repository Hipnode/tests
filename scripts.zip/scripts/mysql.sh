#!/bin/bash
read -p "Quantas pessoas você quer cadastrar? " n;

for (( i = 1; i <= $n; i++ ));do
	echo ""
	echo "PESSOA $i"
	read -p "Nome: " nome;
	read -n2 -p "Data de Nascimento: " dia; read -n2 -p- mes; read -n4 -p- ano; echo '' 
	read -p "Sexo: " sexo;
	read -p "Peso: " peso;
	read -p "Altura: " altura;
	read -p "Nacionalidade: " nacionalidade;
	mysql -u root -pdois-1=1 -e "INSERT INTO pessoas VALUES(DEFAULT,'$nome','$ano-$mes-$dia','$sexo','$peso','$altura','$nacionalidade')" cadastro 2> /dev/null
	
done


