#!/bin/bash

while true ;do
	for i in $(nmap -sP 192.168.23.1/24 | grep MAC | cut -c 13-30 );do
		echo $i >> wifi.log
		
	done
cat wifi.log | sort -u > Wifi.log
done
