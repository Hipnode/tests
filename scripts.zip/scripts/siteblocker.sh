#!/bin/bash

block(){
	site=$1
	if [[ $site =~ ^w{3}\.[a-z0-9]{1,}\.[a-z]{2,3}$ ]] || [[ $site =~ ^[a-z0-9]{1,}\.[a-z]{2,3}$ ]];then
		echo "Site Válido"
	else
		echo "Site Inválido"
	fi

}

block $1
