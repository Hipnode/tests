#!/bin/bash
echo "$1" > /etc/hostname
echo "$1" > /proc/sys/kernel/hostname
sed -e 2d -e "/^$/i 127.0.1.1 \t$1" /etc/hosts
