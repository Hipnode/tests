#!/bin/bash

function mult(){

	for (( i = 1; i <= $3; i++));do
		if (( $i % $1 == 0 )) && (( $i % $2 == 0 ));then
			echo $i
		fi
	done
}

mult $1 $2 $3
