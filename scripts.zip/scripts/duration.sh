#!/bin/bash
function pi(){
	if [ $1 == 1 ];then
		return "year"
	else
		return "years"
	fi
}


function duration(){
	time=$1
	a=31536000
	ano=$(( $time / $a ))
	dia=$(( (($time % $a) / 86400 )))
	hora=$(( (($time % $a) % 86400) / 3600 ))
	minuto=$(( ((($time % $a) % 86400) % 3600) / 60 ))
	segundo=$(( (((($time % $a) % 86400) % 3600) % 60) ))
	p=(pi $1)
	echo "$ano $p, $dia days, $hora hours, $minuto minutos and $segundo segundos"
}

duration $1
