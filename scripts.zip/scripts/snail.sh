#!/bin/bash

rightToLeft(){
	start=$1;
	end=$2;

	for ((

}

read -p "Number of rows: " rows;
read -p "Number of columns: " cols;

for (( l = 0; l < $rows; l++)); do
	for (( c = 0; c < $cols; c++));do
		read -p "[$l][$c]: " number
		matrix[$l,$c]=$number
	done
done


