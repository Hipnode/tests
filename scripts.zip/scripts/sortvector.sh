#!/bin/bash

array=("a" "v" "n")
IFS=$'\n'
sorted=($(sort <<< "${vector[@]}"))

echo ${sorted[@]}
