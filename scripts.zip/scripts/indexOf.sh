#/bin/bash

declare -a vet

read -p "Quantos número você quer ler? " n

indexOf(){
	let i = 0, vetor = $1, val = $2
	for i in $(seq 0 ${#vetor})
	do
		if [ $vetor[$i] -eq $val ];then
			return $i
		fi
	done
	return -1
}

for i in $(seq 0 $(($n-1)))
do
	read -p "Informe o $(($i+1))º número:" k
	vet[$i]=$k
done

indexOf $vet 4
