#!/bin/bash

if [ ! -f $1 ];then
	echo "Arquivo não encontrado"
else
	cat $1
fi
