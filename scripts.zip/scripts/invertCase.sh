#!/bin/bash
function invert(){
  str1=$( echo $1 | rev );
  for i in `seq 0 ${#str1}`;do
    if [[ ${str1:$i:1} == [[:upper:]] ]];then
      string+=$(echo $str1 | tr '[A-Z]' '[a-z]')
     break
    elif [[ ${str1:$i:1} == [[:lower:]] ]];then
      string+=$( echo $str1 | tr '[a-z]' '[A-Z]')
	break
    fi
  done

  echo $string

}

invert "FsH"

