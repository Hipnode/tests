#!/bin/bash
declare -a array
for i in {1..3}
do
	echo -n "Informe o $(($i+1))º valor: "
	read val
	array[$i]=$val
done

echo ${array[@]}
