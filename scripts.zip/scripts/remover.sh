#!/bin/bash

declare -A nomes

while read linha; do
	if [ $(grep -c $(echo $linha | cut -d' ' -f2) $1) -gt 1 ];then
		echo $linha
	fi
done < $1
