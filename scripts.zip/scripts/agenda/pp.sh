#!/bin/bash
grep "$1" telefones
