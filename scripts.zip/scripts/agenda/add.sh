#!/bin/bash

printf "%-10s %10s" "$1" "$2" >> telefones
sort telefones -o telefones
