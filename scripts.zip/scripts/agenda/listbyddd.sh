#!/bin/bash
if [[ $# == 0 ]];then
	echo "Você precisa passar algum parâmetro"
	exit 1
fi

if [[ "$1" =~ ^0[1-9][0-9]$ ]];then
	if [[ $( grep "$1" telefones | wc -l ) > 0 ]];then
		grep -w "$1" telefones --color=none
	else
		echo "Não há números com o DDD $1"
	fi
else
	echo "Informe um DDD válido"
fi
