#!/bin/bash

grep -v "$1" telefones > /tmp/$$
mv /tmp/$$ telefones
