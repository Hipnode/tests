#!/bin/bash

seq -s \* 1 $1 | bc

