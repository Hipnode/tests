#!/bin/bash

for FILE in *.*
do
	if [[ ${FILE} =~ ^[cC] ]]
	then
		echo ${FILE}
	fi
done

