#!/bin/bash

for FILE in *.*
do
	mv ${FILE} ${FILE,,}
done
