#!/bin/bash

for i in {1..10};do
	echo -n "${i} "
	sleep 2
done > meufifo
