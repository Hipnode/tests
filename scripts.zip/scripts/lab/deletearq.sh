#!/bin/bash

SCRIPT_NAME=$0
echo $SCRIPT_NAME

for file in *.txt
do
	[[ $(echo ${file%.*})  =~ [aeiou] ]] && rm $file
done


