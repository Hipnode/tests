#!/bin/bash

read -p "Escreva a sua tarefa: " task
read -p "Nível de Urgência[1 a 3]: " op

	case $op in 
		1) echo 'echo -e "\e[41;1m $task \e[m" ' >> meua.txt;;
		2) echo 'echo -e "\e[43;1m $task \e[m" ' >> meua.txt;;
		3) echo 'echo -e "\e[42;1m $task \e[m" ' >> meua.txt;;
	esac
source meua.txt
