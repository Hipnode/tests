#!/bin/bash

if [ $# \< 2 ]; then
	echo "Número de parâmetros insuficientes. Informe <número> <potência>" 
else 
	for numero in {1..$2}
		do
			r=$(( $r * $1 * $1 ))
	done 
fi
echo $r

