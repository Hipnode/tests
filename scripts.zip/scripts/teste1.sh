#!/bin/bash
function pi(){
	[[ $1 == 1 ]] && return "years" || return "year"

}

p=pi $1
