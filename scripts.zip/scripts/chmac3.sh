chmac(){
	MAC="$1"
	INT="$2"
 	VALID_MAC="^([0-9A-Fa-f]{2}(:|-)){5}[0-9A-Fa-f]{2}"
	if [ $UID == 0 ];then

		if [[ $MAC =~ $VALID_MAC ]]; then
			ifconfig $INT down 2> /dev/null
			ifconfig $INT hw ether $MAC 2> /dev/null
			ifconfig $INT up 2> /dev/null
			[[ $? == 0 ]] && echo "Endereço MAC trocado com sucesso!!" || echo "Ops..houve algum problema"
		
		else
			echo "Informe um MAC válido"
			echo "Saindo..."
		fi 
	else
		echo "Execute como root"
		echo "Saindo..."
	fi
}

chmac $1 $2
