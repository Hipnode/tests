#!/bin/bash
declare -A matriz;
for (( i = 0; i < 3; i++ ));do
	for (( j = 0; j < 3; j++ ));do
		read -p "Posição [$i,$j]: " num
		matriz[$i,$j]=$num
			if [ $i == $j ]; then
				sum=$[ $sum + ${matriz[$i,$j]} ];
			fi
	done
done 


for (( i = 0; i < 3; i++ ));do
        for (( j = 0; j < 3; j++ ));do
                printf "${matriz[$i,$j]} "
        done
	printf "\n"
done 

printf "$sum" 

