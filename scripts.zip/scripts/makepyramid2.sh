#!/bin/bash

clear
echo -n "Enter the level of pyramid: "; read n

star=''
space=''

for ((i=0; i<n; i++ ))
do
space="$space"
done

echo "$space"

for (( i=1; i<n; i++ ))
do

star="$star*"
space="${space%?}"
echo "$space$star$star";

done
