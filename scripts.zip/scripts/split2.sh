#!/bin/bash

split(){
	if [[ ! -z $2 ]];then  
        	read -a vetor <<< $( echo $1 | tr $2 " " )
	else 
		echo OK
		read -a vetor <<< "$1" 
	fi
}	

split "WellintonTdoTAmaralTBotelho" "T"

echo ${vetor[@]}
