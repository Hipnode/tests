#!/bin/bash
cat << "<html> 
<head><title> Informações sobre o sistema</title></head>
echo $?
