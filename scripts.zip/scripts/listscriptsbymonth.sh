#!/bin/bash

meses=('Jan' 'Fez' 'Mar' 'Abr' 'Mai' 'Jun' 'Jul' 'Ago' 'Set' 'Out' 'Nov' 'Dez' )

for mes in ${meses[@]}
do	
	echo "$mes": $( ls -l | awk "$6 ~ /$\{meses[@]\}/ { print $0 }" | wc -l )
	
done 

