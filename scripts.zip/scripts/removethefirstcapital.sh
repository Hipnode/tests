#!/bin/bash

read -a arr <<< $(cat $1 | tr '\n' ' ')

echo ${arr[@]/#[A-Z]/.}
