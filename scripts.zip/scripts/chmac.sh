#!/bin/bash
#Autor: Wellinton Botelho
#Contato: wellinton990@hotmail.com
#Uso: ./chmac interface mac
#Exemplo: ./chmac wlan0 9P:23:2E:N8:A1:3E
chmac(){
	
 	VALID_MAC="^([0-9A-Fa-f]{2}(:|-)){5}[0-9A-Fa-f]{2}"
	if [ $UID == 0 ];then

		if [[ "$1" =~ $VALID_MAC ]]; then
			ifconfig $2 down 2> /dev/null
			ifconfig $2 hw ether $(echo $1 | tr \- \: ) 2> /dev/null
			ifconfig $2 up 2> /dev/null
			[[ $? == 0 ]] && echo "Endereço MAC trocado com sucesso!!" || echo "Ops..houve algum problema"
		
		else
			echo "Informe um MAC válido"
			echo "Saindo..."
		fi 
	else
		echo "Execute como root"
		echo "Saindo..."
	fi
}

chmac $1 $2
