#!/bin/bash

if [[ "$1" =~ ^([1-9]{1}[0-9]{,2}\.){3}[1-9]{1}[0-9]{,2}$ ]];then
	echo Sucess
else
	echo Fail
fi
