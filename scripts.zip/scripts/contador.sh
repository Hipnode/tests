#!/bin/bash
clear
cont=0;
read -p "Informe o tempo em segundos: " n;
	c=$(($n*60))
	for i in `seq 1 $c`; do	
		   if [ $i -eq 60 ]; then
				i=0;
                                cont=$((cont + 1))
                   fi

		echo "$cont:$i"
		sleep 1
		clear
	done
