#!/bin/bash

alfa1=("a" "b" "c" "d" "e" "f" "g" "h" "i" "j" "k" "l" "m" "n" "o" "p" "q" "r" "s" "t" "u" "v" "w" "x" "y" "z")
declare -a men
read -p "Informe a mensagem: " mens
read -p "Informe a o número da chave: " key

for k in `seq 0 ${#mens}`;do
	newmen[$k]=${mens:$k:1}
done

for i in ${!newmen[@]};do
	for j in ${!alfa1[@]};do
		if [ "${newmen[$i]}" == "${alfa1[$j]}" ];then
			if (( ($j+$key) \< ${#alfa1[@]} ));then
				echo  ${alfa1[$j+$key]}
				newmen[$i]=${alfa1[$j+$key]}
			else
				newmen[$i]=${alfa1[$j+$key%26]};
			fi
		fi		
		#echo -n "${alfa1[$j+$key]}"
		
	done
done 

echo ${newmen[@]}

#for n in ${!newmen[@]};do
#	echo -n "${newmen[$n]}"
#done
