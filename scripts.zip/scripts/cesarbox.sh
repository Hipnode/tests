#!/bin/bash
function sqrt(){
	for (( i = 0; i < $1; i++ ));do
			if (( $i*$i == $1 )); then
				#echo $i
				return $i
			fi
	done

}

declare -A box
declare -a msg
c=0
read -p "Informe a mensagem: " mens
#for ((i = 0; i < ${#mens}; i++));do
#	msg[$i]=${mens:$i:1}
#done


#for i in {1..9};do
#	echo ${msg[$i]};
#	((c++))
#done
raiz=`echo "sqrt(${#mens})" | bc` 
for (( i = 0; i < $raiz; i++ ));do
	for(( j = 0; j < $raiz ; j++ ));do
		box[$i,$j]=${mens:$c:1}
		((c++))
	done
done

for (( i = 0; i < $raiz; i++ ));do
	for (( j = 0; j < $raiz; j++ ));do
		msg[$c]=${box[$j,$i]}
		((c++))	
	done
done

for i in `seq 0 ${#mens}`;do
	echo -n "${mens[$i]}"
done
