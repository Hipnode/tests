#!/bin/bash

echo ""
echo -n "Loading"
for i in {1..10};do
	echo -n .
	sleep 1
done
