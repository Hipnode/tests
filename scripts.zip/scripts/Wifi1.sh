#!/bin/bash
clear
if [ $UID == 0 ]; then
	while true 
	do
		
		for i in `nmap -sP 10.42.0.1/24 | grep -i mac | cut -c 13- `
		do
			echo $i
		done 

	sleep 10 
	clear
	done
else 
	echo "Execute como root"

fi
