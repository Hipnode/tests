month=" $(echo ${1:0:3} | tr 'a-z' 'A-Z') "

echo $month
