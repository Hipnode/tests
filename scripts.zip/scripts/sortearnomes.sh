#!/bin/bash

for i in {1..10}; do
	echo "Informe o $i nome"
	read ${vetor[i]};

