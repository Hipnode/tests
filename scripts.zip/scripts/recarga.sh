#!/bin/bash

function diasuteis(){
	dis=$[ $2 - $1 ]
	for i in {1..$dis}; do
		if(( $i % 7 -eq 0 )); then
			count=$[$count + 2]
		fi

	

}

dr=$( cat recarga.txt | tail -1 | awk '{ print $1 }')
da=$( date +%d )
q=$( cat recarga.txt | tail -1 | awk '{ print $2 }' )
qp=$[ $q - (($da - $dr) * 2 ) ]
echo "Quantidade de passagens: $qp "
