#!/bin/bash

echo $LINENO
echo $SECONDS
