#!/bin/bash
clear
gcc $1 -o `echo $1 | cut -d"." -f 1`
./`echo $1 | cut -d"." -f 1`
