#!/bin/bash
cat /proc/partitions | awk '/sda[0-9]$/ { print "Partição: ",$4, "Tamanho: ", ($3/1024)/1024, "GB"  }'


