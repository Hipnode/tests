#!/bin/bash

for arq in `ls | cut -d'.' -f2`; do
	if [ $arq == "sh" ]; then
		count=$[ $count + 1 ]
	elif [ $arq == "c" ]; then
		countc=$[ $countc + 1 ]
	fi
done

echo "Quantidade de arquivos sh: $count"
echo "Quantidade de arquivos c: $countc"
