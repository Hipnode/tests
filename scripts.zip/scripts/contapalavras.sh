#!/bin/bash
egrep -o '\w+' | grep ... | sort -f | uniq -c -i | sort -n -r | head
