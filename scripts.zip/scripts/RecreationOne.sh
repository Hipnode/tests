#!/bin/bash
list_squared(){
	sum=0
	for (( i = $1; i <= $2; i++ ));do
		for (( j = 1; j <= $i; j++ ));do
			if (( $i % $j == 0 ));then
				quad=$( bc <<< "$j^2" )
				sum=$( bc <<< "$sum+$quad" )
				sqrt=$( bc <<< "sqrt($sum)")
		
			fi

			for (( k = 1; k < $sum; k++ ));do
				if (( $k * $k == $sum ));then
					echo $i
				fi
			done
		done
		
	done

	
}

list_squared $1 $2


