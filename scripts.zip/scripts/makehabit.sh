#!/bin/bash
row=0;
col=0;
declare -A mt
while true;do
clear
read -n 1 -p "Vc fez a sua tarefa hoje (s/n)? " resp; 
	if [ $resp == "s" ] || [ $resp == "S" ];then
		mt[$row,$col]="X"
		(( col++ ))
			if [ $col -gt 10 ];then	
				col=0;
				(( row++ ));
			fi
	fi

printf "\n"
for (( i = 0; i < 6; i++ ));do
	for (( j = 0; j < 11; j++));do
		if [ ! -z ${mt[$i,$j]} ];then 
			printf " ${mt[$i,$j]} |"
		else
			printf " ${mt[$i,$j]}  |"
		fi
		
	done
	printf "\n"
done		
read ad;
done
