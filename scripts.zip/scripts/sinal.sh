#!/bin/bash
function esc1(){
	echo
	echo
	echo
	echo 
	echo "##"
}

function esc2(){
	echo
	echo
	echo "     "
	echo "   ##"
	echo "## ##"
	
}

function esc3(){
	echo 
	echo
	echo "      ##"
	echo "   ## ##"
	echo "## ## ##"

}
while true 
	do
		if [ $( iwconfig `ifconfig | grep ^w | awk '{ print $1 } ' ` | grep level | cut -d'=' -f3 | cut -d' ' -f1 | sed 's/-//' ) \< 70 ]; then
			esc1
		else
			esc2
			sleep 10
			clear
		fi
done


