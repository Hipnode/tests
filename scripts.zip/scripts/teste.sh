#!/bin/bash

hex=( ["A"]=10 ["B"]=11 ["C"]=12 ["D"]=13 ["E"]=14 ["F"]=15 )

read -p "Digite uma letra: " l
S=0
for i in $( seq 0 $((${#l}-1)) )
do
	S=$(( $S + 
done
