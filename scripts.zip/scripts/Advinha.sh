#!/bin/bash
until [ $num -ne 0 ]; do
read -p "Informe um número: " num;
rad=$[ $RANDOM % 9 ]
	if [ $num == $rad ]; then
		echo "Acertou!!" 
	else 
		if [ $num > $ra ]; then
			echo "O número é maior"
		else
			echo "O número é menor"
		fi
	fi
done
