#!/bin/bash

function slice(){
	str=$1
	start=$2
	end=$3
	echo "${str:$start:$end}"
}

e=$(slice "jeziel" 1 2)
echo $e
