#!/bin/bash
ps -aux | grep -i $1 | grep -v color | awk '{ print $2 }' | paste -s -d' ' | xargs -i kill '{}'
