#!/bin/bash
declare -a myarray

read -a myarray < times.txt

for i in ${!myarray[@]};do
	echo ${myarray[$i]}
done
