#!/bin/bash

while true; do
clear
figlet `date +%H:%M:%S`
sleep 1
done
