#!/bin/bash

function split(){
	STR=$1
	DELIMITER=$2
	
	for i in $( seq 0 ${#STR} );do
		if [[ ! -s $DELIMITER ]];then
			STRING[$i]=$( echo $STR | cut -d$DELIMITER -f $(($i + 1)) )
		else
			STRING[$i]=$( echo $STR | cut -d' ' -f $(($i + 1)) )
		fi	
	done

}

split "Wellinton Botelho" " "
echo ${STRING[1]}
