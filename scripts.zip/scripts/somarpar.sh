#!/bin/bash

somarpar(){

	if [ $1 == 2 ];then
		return 2;
	else
		if [ `expr $1 % 2` == 0 ];then
			return $[ $1 + somarpar $(( $1 - 2 )) ];
		else
			return $1 + somapar $1
		fi
	fi

}

echo -n "Informe um número: "
read num;

somarpar $num
