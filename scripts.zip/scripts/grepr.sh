#!/bin/bash

find $1 -type f -exec grep -i -l "$2" {} \;
