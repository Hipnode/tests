#!/bin/bash
maior=0
echo -n "Informe o tamanho do vetor: "
read tam
for (( i = 0; i < $tam; i++ ))
	do
		echo -n "Informe o $(( $i + 1 ))º valor: "
		read val
		array[$i]=$val
			if (( ${array[$i]} \> $maior )); then
				maior=${array[$i]}
				
			fi
done

echo "${array[@]}"
echo "$maior"
