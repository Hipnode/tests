#!/bin/bash

read -p "Informe o número binário: " bin;

for (( i = 1; i <= ${#bin}; i++));do
	decimal += $[ ${bin:$i-1:1}*

