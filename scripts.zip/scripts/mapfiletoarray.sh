#!/bin/bash

while read line;do
	arr=(${arr[@]} $line)
done < $1

echo ${arr[@]}
