#!/bin/bash

declare -A teste

teste=( 
	["A"]=10
	["B"]=11 
	["C"]=12 
	["D"]=13 
	["E"]=14 
	["F"]=15 
)

patt=$( echo ${!teste[@]} | tr ' ' '|')

[[ $1 =~ ^($patt)$ ]] && echo "Contém"

