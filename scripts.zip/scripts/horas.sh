#!/bin/bash

horas=`date | cut -d' ' -f4 | cut -d':' -f1`

if (( $horas >= 6 )) && (( $horas <= 12 ))
then
	echo "Bom dia!!"
elif (( $horas >= 12 )) && (( $horas < 18 ))
then
	echo "Boa tarde!!"
else
	echo "Boa noite!!"
fi

