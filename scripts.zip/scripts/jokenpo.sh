#!/bin/bash
menu(){
echo "Pressione 0 para sair"
echo " 1 - Pedra"
echo " 2 - Papel"
echo " 3 - Tesoura"
read -p "Opção: " op
	if [ $op -gt 0 ] && [ $op -le 3 ]; then
	cpu=$(($RANDOM % 3))
	case $cpu in 
		0) echo "CPU: Pedra";;
		1) echo "CPU: Papel";;
		2) echo "CPU: Tesoura";;
	esac
			if [ $op -eq 1 -a $cpu -eq 2 -o $op -eq 2 -a $cpu -eq 0 -o $op -eq 3 -a $cpu -eq 1 ]; then
				echo "Você ganhou!!"
			elif [ $op -eq $[$cpu + 1] ]; then
				echo "Deu empate"
			else
				echo "A CPU ganhou"
			fi
	read -p "Pressione ENTER para continuar..." enter;
	clear
	menu
	else 
		exit
	fi
}
menu


