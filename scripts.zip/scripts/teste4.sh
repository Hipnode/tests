#!/bin/bash
soma=0
c=1
for i in $(seq $#);do
	(( $# > 9 )) && shift 9 && c=1;
	eval n=\$${c}
	soma=$(( soma + n ))
	((c++))

done

echo $soma	
