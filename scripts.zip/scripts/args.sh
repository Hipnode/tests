#!/bin/bash
i=1;
while [ $i -le $# ];do
	eval param=\$$i
	echo ${param:1}
	((i++))
done
