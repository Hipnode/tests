#!/bin/bash
declare -a array
read -p "Informe o número de notas: " n

for (( i = 0; i < n; i++ )); do
	echo -n "Informe a $(( $i + 1 ))º nota: "  
	read numero
	array[$i]=$numero
	soma=$[ $soma + ${array[$i]} ]
done

media=$( echo "scale=2; $soma / $i" | bc )

if (( $media -ge 7 )); then
	echo "Você foi aprovado"
fi
