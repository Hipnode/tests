#!/bin/bash

#Declara um vetor associativo ou hash
declare -A hash

read -p "String: " str
read -a vet <<< "$str"

for char in ${vet[@]}
do	
	hash[$char]=$( echo $str | tr ' ' '\n' | grep -c $char ) 
done

for char in ${!hash[@]};do
	echo $char: ${hash[$char]}
done
