#!/bin/bash
function mostra(){
	select script in `ls ~/scripts/ | cut -d'.' -f1`;do
		cat ~/scripts/$script.sh
		read -p "Pressione ENTER para voltar ao menu" voltar
		clear
		mostra	
	done
}

mostra
