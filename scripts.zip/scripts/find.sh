#!/bin/bash

findy(){
	dir=$1
	if [ $# == 0 ];then
		echo "Nothing to find"
	else
		if [ ! -d $dir ]; then
			echo "Directory not found"
		else
			f=$(find $dir -type f | wc -l)
			echo "There are $(($f-1)) files in $dir"
		fi
	fi
}

findy $1
