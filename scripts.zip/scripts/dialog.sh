#!/bin/bash

while : ; do

    # Mostra o menu na tela, com as ações disponíveis
    resposta=$(
      dialog --stdout               \
             --title 'AutoComer'  \
             --menu 'Opções:' \
            0 0 0                   \
            1 'Incluir cliente' \
            2 'Consultar cliente'  \
            3 'Excluir cliente'     \
            4 'Incluir produto'        \
            0 'Sair'                )

    # Ela apertou CANCELAR ou ESC, então vamos sair...
    [ $? -ne 0 ] && break

    # De acordo com a opção escolhida, dispara programas
    case "$resposta" in
         1) nome ;;
         2) /bin/mcedit /tmp/carta.txt ;;
         3) /usr/games/solitaire ;;
         4) /usr/X11R6/bin/xsnow ; /usr/X11R6/bin/xeyes ;;
         0) break ;;
    esac

done
