#include<stdio.h>
char mat[4][10]={"Limite","Derivada","Integral","seila"};
int i;
float rend,total;
int main(){
	for( i = 0; i < 4; i++){
		printf("Rendimento de %s: ", mat[i]);
		scanf("%f", &rend);
		total+=rend*25/100;
	}

	printf("Estimativa de nota: %.2f%% \n", total);
	return 0;
}
