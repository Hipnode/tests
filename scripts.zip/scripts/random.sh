#!/bin/bash

for n in {1..9};do
	x=$RANDOM
	[ $x -lt 2000 ] && break
	echo "n=$n x=$x"
done
