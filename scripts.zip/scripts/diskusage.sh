#!/bin/bash
i=0;
declare -A vet
for file in *.txt *.pdf *.c *.html;do
	vet[$i]=$(find ~ -type f -name \$file -exec du {} \; | awk '{ sum+=$1 }END{ print sum }' )
	((i++))
	printf "${vet[$i]}"
done


