#!/bin/bash
reverse(){
	if [ `echo $1 | awk '{ print NF }'` == 1 ];then
		echo $1 | rev
	else
		echo -n "$1 " | tac -s ' '
	fi
}

reverse "$1"
