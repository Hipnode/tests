#!/bin/bash

read -p "Partição do Ubuntu: " part
mount -t ext4 /dev/$part /mnt
mount -o bind -t proc /proc /mnt/proc
mount -o bind /sys /mnt/sys
mount -o bind /dev /mnt/dev
mount -o bind /dev/pts /mnt/dev/pts
chroot /mnt

grub-install --root-directory=/mnt /dev/sda
grub-update

