#!/bin/bash

declare -A ar

ar=( ['Wellinton']='Zenphone' )


echo ${arr[Wellinton]}
