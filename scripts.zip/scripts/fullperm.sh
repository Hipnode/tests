#!/bin/bash

for perm in $*;do
	chmod 777 $perm
done
