#!/bin/bash

get_volume(){
	bc <<< $1*$2*$3
}

get_volume $1 $2 $3
