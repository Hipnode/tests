#!/bin/bash
repeatStr(){
repeat=$1
string=$2
  for i in `seq 1 $1`;do
    echo -n $string
  done
}
repeatStr $1 $2
