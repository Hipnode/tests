#!/bin/bash
read -p "Informe seu nome: " nome;

echo "Gerando o relatório Sr. ${nome##* }"
sleep 3;
echo "Usuários ativos: `who | wc -l`"
echo "Usuários conectados a rede: `nmap -sP 10.42.0.1/24 | grep -i mac | cut -c 13-30 | wc -l`"
echo "Obrigado Sr. ${nome##* }"
