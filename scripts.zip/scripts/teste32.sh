#!/bin/bash

while read file;do
	[[ $( cat $file | wc -l ) -gt 3 ]] && echo $file
done < <( ls -1 *.txt )
