#!/bin/bash
i=1;
NUMERODEARGUMENTOS=$#
function atualizaRepositorios(){
	apt-get update
}

function atualizaPacotes(){
	apt-get upgrade
}

function atualizaDistribuicao(){
	apt-get dist-upgrade
}

if [[ $NUMERODEARGUMENTOS == 1 ]];then
	ARGUMENTO="1"
	while [ $ARGUMENTO ];do
		ARGUMENTO="${1:$i:1}"
		case "$ARGUMENTO" in 
			'u') atualizaRepositorios;;
			'U') atualizaPacotes;;
			'D') atualizaDistribuicao;; 
			*) echo "Opção inválida"; break
		esac

		((i++))

	done

elif [[ $NUMERODEARGUMENTOS > 1 ]];then
	eval ARGUMENTO=\$$i
	while [ $ARGUMENTO ];do
		ARGUMENTO="${ARGUMENTO:1}"
		case $ARGUMENTO in 
			'u') atualizaRepositorios;; 
			'U') atualizaPacotes;; 
	        'D') atualizaDistribuicao;;
			 *) echo "Argumento $ARGUMENTO inválido";break
		esac
		
		((i++))
	done
fi
	
