#!/bin/bash

URL="https://todo-app-vanilla.firebaseio.com"

read -p "Título: " title
read -p "Foi finalizada?  " don

JSON=$(printf '{"title":"%s", "done":"%s"}' ${title} ${don})

curl -X POST -d "$JSON" "${URL}/todos.json"




