#!/bin/bash
count=0
read -p "Informe um número negativo: " numero
while [ $numero \< 0 ];do
	(( numero++ ))
	(( count++ ))
done

echo $count
