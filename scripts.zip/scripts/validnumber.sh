#!/bin/bash

validPhoneNumber(){
	[[ $1 =~ ^\([0-9]{3}\)' '[0-9]{3}-[0-9]{4}$ ]] && echo "True" || echo "False"

}
validPhoneNumber "$1"
