#!/bin/bash
read -p "Informe um número: " n;
	c=$( expr $n % 2)
	if [ $c -eq 0 ]; then
		echo "Par"
	else
		echo "Não é par"
	fi
