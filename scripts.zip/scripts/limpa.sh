#!/bin/bash

for file in *.txt
do
	[ ! -s $file ] && 
	echo "Removendo $file..."
	rm $file
done
